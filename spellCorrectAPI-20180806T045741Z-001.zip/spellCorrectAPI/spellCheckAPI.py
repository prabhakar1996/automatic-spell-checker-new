#!flask/bin/python
from flask import Flask
from flask import request
import enchant
import json
import os
import CustomSpellingReplacer as CSR
from flask_httpauth import HTTPBasicAuth
auth = HTTPBasicAuth()


d=enchant.Dict()

cusSpell = CSR.CustomSpellingReplacer(d)

app = Flask(__name__)

@app.route('/')
def index():
    return "<html> <h2> Hello! </h2> <BR> <h4> This is spellCorrect API </h4><BR>  <B> USAGE: <BR> http://127.0.0.1:5000/spellCorrect?ss=some word </B> </html>"


@app.route('/spellCorrect', methods=['GET', 'POST'])
#@auth.login_required
def findSpelling():
    searchString = str(request.args.get('ss'))
    #user = str(request.args.get('u'))
    #password = str(request.args.get('p'))
    
    x1=searchString.split()
    print(x1)
    y=list();
    z = list();
    
    for i in (range(0,len(x1))):
        y.append(cusSpell.spellCorrector(x1[i]))
        z.append(y[i][0])
    print ('Results: '+json.dumps(y))
    return json.dumps(y)

#@auth.verify_password
def verify_password(username, password): 
    username = str(request.args.get('username'))
    password = str(request.args.get('password'))
    #print ('PRE:  username: '+username+' password: '+password)
    if not username=='abhay' or not password=='bhadani':
        print ('Wrong username or password !!! Aborting ....')
        return False
    else:
        #print ('TRUE:  username: '+username+' password: '+password)
        return True


if __name__ == '__main__':
    app.run(debug=True)
