# Base class 
class SpellingReplacer(object):
       
    def __init__(self, dict_name='en_US', max_dist=3):
        
        self.dict_name=dict_name
        self.spell_dict = enchant.Dict(dict_name)
        self.max_dist = max_dist
    

# Derived Class    
class CustomSpellingReplacer(SpellingReplacer):
    
    import FetchDictionary   # importing the FetchMedicalDictionary class created by us
    
    fmd=FetchDictionary.FetchDictionary()
    #g1=fmd.load_dict()
    
    def __init__(self, spell_dict, dict_name='en_US', max_dist=3):  # max_dist is maximum number of edit distance allowed
        self.spell_dict = spell_dict
        self.max_dist = max_dist
        self.dict_name=dict_name
    
    
    def replace(self, word):
        from nltk.metrics import edit_distance
        max_edit_distance=2
        
        if self.spell_dict.check(word):      # if the word is correct, do nothing
            return 

        suggestions = self.spell_dict.suggest(word)  # Otherwise, provide suggestions
        
        if not suggestions :                         # If there are no suggestions, do nothing
            print( 'No Spelling Suggestions Found in the Dictionary.' )
            
        else :                                       # Otherwise, return the suggestions
            for i in suggestions :
                # Transposition are most commonly made errors make its edit distance = 0 (TO BE DONE)
                if not (edit_distance(word, i, transpositions=False) <= max_edit_distance): 
                    suggestions.remove(i)
            
            return suggestions  #[0:]
  
              
    
    # N=5 , number of suggestions by default is set to 5
    def spellCorrector(self, x, N=2):   
      
        import operator
        import itertools
        import enchant
        from nltk.metrics import edit_distance
        
        finalSuggestions=list()
        #dictFileSorted = 'data/customDic/mycustomdict.dic.sorted'
        
        # Create an instance with  a custom dictionary, created from outside
        #d = enchant.DictWithPWL(self.dict_name,pwl=dictFileSorted)    
        d = enchant.Dict(self.dict_name)    

        # Call the CustomSpellReplacer function
        replacer = CustomSpellingReplacer(d)
        
        # get the suggestions of x 
        c = replacer.replace(x)
        #g1 = replacer.g1   # load medical dict separately, for prioritizing the suggestions

        # If the spelling is correct, then nothing is returned, hence there is no need for executing the below code block

        if c :
            c = map(str.lower,c)
            # add commonly used english words to dict and compare      

            m = {}

            # Iterating over all words in list c and removing those words which have already 
            # occurrred Once in the Dictionary/Hash map and assigning a unique index value
            # to each word in our dictionary.

            index = 0 

            for i in c:   
                if i not in m :
                    m[i] = index
                    index = index+1

            # Add all the dictionary keys to a list c
            c = list(m.keys()) 

            # Dictionary Frequency filter

            a = {}
            # g1 = dict(itertools.zip_longest(*[iter(c)] * 2, fillvalue=""))
            # if the word is found in the dictionary from combined.txt then it is added to another dict a otherwise discarded. 
            # for i in c:
            #    if i in g1 :
            #        a[i] = g1[i]

            # remain = list(set(c) - set(a.keys()))

            # sorting the dictionary on the basis of frequency of its occurence in combined.txt.
            # a = sorted(a.items(), key=operator.itemgetter(1),reverse=True)

            # for item in a:
            #    finalSuggestions.append(item[0])

            # for item in remain:
            #    finalSuggestions.append(item)

            #finalSuggestions = finalSuggestions[0:min(N, len(finalSuggestions))]
            
            finalSuggestions = c # finalSuggestions[0:min(N, len(finalSuggestions))]

        else:

            finalSuggestions.append(x)
        
        
        return finalSuggestions;

