class FetchDictionary:
    
    def __init__(self):
        ''' Constructor for this class. '''
        # Assign some variables 
        #self.N=5
        self.corpusFile='data/corpus/new_codes.utf8-v2'
        self.customDictFile='data/corpus/corpusdictonary.dic'
        
    def clean_corpus(self):
        import enchant
        import re
        import codecs
        import itertools 
        import operator
        import json
        
        d = enchant.Dict('en_US')
        g = {}
        # Pass the data curated from 3 months search history
        corpus        = open(self.corpusFile,'r').readlines()
        corpusCleaned = codecs.open(self.corpusFile+'.cl','w+','utf-8')
        corpusJunk    = open(self.corpusFile+'.jk','w+')

        pattern = r'[!+|[+|]+|{+|}+|"+|\'+|\\n+|,+|/+|\(+|\)+|@+|:+|<+|>+|&+|#+|;+|-+| +|_+|;+|-+|\*+|~+|=+|\?+|\^+|%+|\\+|/+|\w+]'

        # read all the words from medical dictionary and make a list
        for line in corpus :
            for i in re.split(pattern, line.lower()):
                i = i.strip().strip('.').strip(',').strip(']').strip('\'')

                legal_characters = r'[^a-zA-Z0-9\.\\-]+$' # Matches Unicode word characters
                r = re.compile(legal_characters, re.IGNORECASE)

                if (len(i)>3):
                    if (re.search(r, i)) :
                        corpusJunk.write("%s \n" %i)
                        ooo=0
                    else:    

                        if i in g :
                            g[i] = g[i] + 1
                        else :
                            g[i] = 1

                        if (d.check(i)==False) :
                            corpusCleaned.write("%s \n" %i)

        g = dict(sorted(g.items(), key=operator.itemgetter(1),reverse=True))

        with open(self.customDictFile, 'w') as m:
            for key, value in g.items():
                m.write('%s\n' % (key))
        # create  a json with key, value pair
        # It will be used for prioritizing the spell suggestions
        json.dump(g, open(self.customDictFile+'.json','w'))
        
        corpusCleaned.close()
        corpusJunk.close()
        m.close()

        #return g

    def load_dict(self):
        import json
        g1=json.load(open(self.customDictFile+'.json'))
        return g1
    
